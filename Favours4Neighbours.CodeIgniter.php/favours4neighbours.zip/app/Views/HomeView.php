<main>
	<div class="heroe">
		<h1>Welcome to Favours4Neighbours <?php echo $username;?>!</h1>
		<p>The neighbourhood application linking you with your neighbourhood</p>
	</div>
</main>
