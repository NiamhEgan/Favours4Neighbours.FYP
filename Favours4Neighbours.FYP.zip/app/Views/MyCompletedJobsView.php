<table class="table table-striped">
	<caption class="caption-top">My Completed Jobs</caption>
	<thead>
		<tr>
			<th scope="col">Date Completed</th>
			<th scope="col">Created By</th>
			<th scope="col">Job Details</th>
			<th scope="col">Status</th>
			<td>&nbsp;</td>
		</tr>
	</thead>
	<tbody>
	
	
	</tbody>
</table>