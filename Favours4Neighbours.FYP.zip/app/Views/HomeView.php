<title>Admin Home </title>
<div class="jumbotron text-center">
<h1>Welcome to Favours4Neighbours <?php echo $username;?>!</h1>
<p>The neighbourhood application linking you with your neighbourhood</p>
</div>
  
<div class="container">
  <div class="row">
    <div class="col-sm-4">
      <h3>How it works </h3>
      <p>On Favours4Neighbours either create a job you need done, or apply for job your neighbour needs done. </p>
 
    </div>
    <div class="col-sm-4">
      <h3>Neighbourshood News </h3>
      <p>Check out the latest jobs in your area...</p>
  
    </div>
    <div class="col-sm-4">
      <h3>Jobs Include</h3>        
      <p>Dog Walking</p>
      <p>Grocery Shopping</p>
      <p>Bike Repair </p>
      <p>Technical Support and more!</p>
   
    </div>
  </div>
</div>

</body>
</html>
